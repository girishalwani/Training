
"""
TM01- mini project
proj1
"""

distance = float(input(" enter the distance in miles ? " ))
if distance<3:
    print(" I suggest you to take Bicycle to your destination ")

elif distance>=3 and distance<300:
    print(" I suggest you to take Motor-cycle to your destination ")

else:
    print(" I suggesr you to take super-car to your destination ")
    
