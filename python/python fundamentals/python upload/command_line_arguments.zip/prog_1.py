"""
Write a program to accept two numbers as command line
arguments and display their sum.
"""


import sys
a=sys.argv[1]
b=sys.argv[2]

sum = int(a)+int(b)

print("sum = ",sum)
