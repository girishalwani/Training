"""
Write a program to check if a given key already exists in a dictionary.
"""

dict = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}

print(dict)
if(1 in dict):
    print('key present in dictionary')
else:
    print('key not in dictionary')
    
