"""
Write a program to add a key and value to a dictionary.
"""

dict = {0:10,1:20}
print('old dict',dict)
dict[2]=30
print('new dict',dict)
