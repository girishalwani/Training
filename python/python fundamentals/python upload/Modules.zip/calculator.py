import math_module
print("Addition",math_module.add(10,5))
print("Subtraction",math_module.sub(10,5))
print("Multiplication",math_module.mul(10,5))
print("Division",math_module.div(10,5))
