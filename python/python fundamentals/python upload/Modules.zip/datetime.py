import _datetime
a=_datetime.date.today()
print(a)
    
