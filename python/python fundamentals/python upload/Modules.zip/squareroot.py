import math
print(math.sqrt(100))
    
    
