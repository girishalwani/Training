"""
Write a program to convert a list into a tuple.
"""

list=[1,2,3,4,5,'a','b','c','d','e']
print('list',list)

tup=tuple(list)
print('tuple',tup)
