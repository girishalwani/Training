"""
Write a program to print the 4th element
from first and 4th element from last in a tuple.
"""


tup = (1,2,3,4,5,6,7,8,9,0)

print('4th element from first',tup[3])
print('4th element from last',tup[-4])
