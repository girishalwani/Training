"""
Write a program to check whether an element exists in a tuple or not.
"""

tup = ("car","bus","plane","bike")

if 'plane' in tup:
    print('element present in tuple')
else:
    print('element not present in tuple')
        
