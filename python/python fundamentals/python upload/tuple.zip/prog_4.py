"""
Write a program to find the index of an item in a tuple.
"""


tup = (1,2,3,4,5,'a','b','c','d','e')
print('index of a in tuple',tup.index('a'))
