"""
create a python module with the following fucntions

(1) ispalindrome(name)
(2) count_the_vowels(name)
(3) frequency_of_letters(name)

"""


import functions

name = input("enter a name -> ")
functions.ispalindrome(name)
functions.count_the_vowels(name)
functions.frequency_of_letters(name)
