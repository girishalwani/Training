SELECT ename, job FROM emp WHERE mgr IS NULL;
