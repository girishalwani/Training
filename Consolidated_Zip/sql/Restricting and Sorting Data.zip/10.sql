SELECT ename, sal FROM emp
WHERE sal> &salary;

