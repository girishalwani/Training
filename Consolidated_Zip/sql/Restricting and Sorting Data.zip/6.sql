
SELECT ename,job,hiredate FROM emp WHERE ename='SCOTT' OR ename='TURNER' ORDER BY 3 ASC;