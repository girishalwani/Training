SELECT ename
FROM emp
WHERE ename LIKE '%A%' AND ename LIKE '%S%';