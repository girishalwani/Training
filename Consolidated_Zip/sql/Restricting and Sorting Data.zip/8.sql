SELECT ename "Employee",sal "Monthly salary" FROM emp WHERE (deptno='20' OR deptno= '30') AND (sal BETWEEN 2000 AND 3000)
