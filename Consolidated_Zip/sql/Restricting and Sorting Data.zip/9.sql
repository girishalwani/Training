SELECT ename,hiredate FROM emp WHERE hiredate LIKE '%81' 
