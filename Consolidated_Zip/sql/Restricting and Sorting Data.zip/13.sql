SELECT empno, ename, sal, deptno
FROM emp
WHERE mgr= &manager
ORDER BY &column