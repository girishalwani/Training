SELECT ename, sal, comm
FROM emp
WHERE comm IS NOT NULL
ORDER BY 2 DESC, 3 DESC;