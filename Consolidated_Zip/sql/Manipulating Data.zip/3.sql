UPDATE EmpTest SET SAL=(SAL*1.15) where ename='TURNER';
SELECT* FROM EmpTest;