MERGE INTO EMP2 T 
USING EMP S
ON(T.EMPNO=S.EMPNO)
WHEN MATCHED
    THEN UPDATE SET  T.ENAME=S.ENAME
    WHERE (T.EMPNO=7788)
WHEN NOT MATCHED 
    THEN INSERT (empno,ename,job,mgr,hiredate,sal,comm,deptno)
         VALUES (S.empno,S.ename,S.job,S.mgr,S.hiredate,S.sal,S.comm,S.deptno)
         WHERE(S.SAL>3000);
      
    
