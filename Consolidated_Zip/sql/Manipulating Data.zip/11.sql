INSERT INTO EMP2(SELECT empno,ename,job,mgr,hiredate,sal,comm,deptno FROM emp);
INSERT INTO EMP3(SELECT empno,ename,job,mgr,hiredate,sal,comm,deptno FROM emp);