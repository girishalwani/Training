UPDATE EmpTest SET SAL=(SELECT SAL FROM EmpTest WHERE ename='SCOTT') where ename='SMITH';
SELECT* FROM EmpTest;