DECLARE
   exp1 exception; 
   pragma exception_init (exp1,-20016); 
   E NUMBER;
   ENAME VARCHAR2(20);
   SAL NUMBER;
   A BOOLEAN;
   O NUMBER;
BEGIN
E:=&EMPNO;
SELECT EMPNO INTO O FROM EMP WHERE EMPNO=E;
RAISE EXP1;
EXCEPTION
     WHEN no_data_found THEN
     INSERT INTO EMP(EMPNO,ENAME,SAL) VALUES(E,'&ENAME','&SAL');
     WHEN EXP1 THEN
     DBMS_OUTPUT.PUT_LINE('Duplicate Record Error');
END;     
