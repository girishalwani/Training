DECLARE
i emp %rowtype;
netsal NUMBER(10);
BEGIN
SELECT ename,job,sal,deptno,comm into
i.ename,i.job,i.sal,i.deptno,i.comm from emp
where empno=&eno;
netsal:=i.sal+NVL(i.comm,0);
DBMS_OUTPUT.PUT_LINE('The emp details are '||'Name:'||i.ename||' Net Salary:'||netsal);
END;
/
