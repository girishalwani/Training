SET SERVEROUTPUT ON
CREATE OR REPLACE PACKAGE pk2 IS
    CURSOR cur RETURN emp%rowtype;
    PROCEDURE disp_first3;
    PROCEDURE disp_first6;
END pk2;

CREATE OR REPLACE PACKAGE BODY pk2 AS
    CURSOR cur RETURN emp%rowtype IS SELECT * FROM emp;
    eval cur%rowtype;    
    PROCEDURE disp_first3 IS
    BEGIN
        OPEN cur;
        LOOP
            FETCH cur INTO eval;
            dbms_output.put_line(eval.ename||','||eval.JOB||','||eval.deptno);
            EXIT WHEN cur%rowcount=3;
        END LOOP;
        CLOSE cur;
    END disp_first3;
    
        PROCEDURE disp_first6 IS
    BEGIN
        OPEN cur;
        LOOP
            FETCH cur INTO eval;
            dbms_output.put_line(eval.ename||','||eval.JOB||','||eval.deptno);
            EXIT WHEN cur%rowcount=6;
        END LOOP;
        CLOSE cur;
    END disp_first6;

END pk2;


BEGIN
    pk2.disp_first6;
    dbms_output.put_line(' ');
    pk2.disp_first3;
END;

