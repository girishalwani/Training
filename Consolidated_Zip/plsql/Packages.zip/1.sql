CREATE OR REPLACE PACKAGE PK1 AS
PROCEDURE ADD_DEPT(DEPTNO NUMBER,DNAME VARCHAR2,LOC VARCHAR2); 
PROCEDURE UPDATE_DEPT(DEPTNO NUMBER,DNAME VARCHAR2,LOC VARCHAR2);
PROCEDURE DELETE_DEPT(DEPTNO NUMBER);
END PK1;
/
CREATE OR REPLACE PACKAGE BODY PK1 AS
FUNCTION CAL_CNT(DNO NUMBER)RETURN BOOLEAN IS
A NUMBER;
BEGIN
SELECT DEPTNO INTO A FROM DEPT WHERE DEPTNO=DNO;
IF A IS NOT NULL THEN
RETURN TRUE;
ELSE
RETURN FALSE;
END IF;
EXCEPTION
WHEN NO_DATA_FOUND THEN
RETURN FALSE;
END CAL_CNT;
/***/
PROCEDURE ADD_DEPT(DEPTNO NUMBER,DNAME VARCHAR2,LOC VARCHAR2) IS
A NUMBER:=DEPTNO;
B VARCHAR2(242):=DNAME;
C VARCHAR2(242):=LOC;
D NUMBER;
exc EXCEPTION;
BEGIN
IF CAL_CNT(A)=FALSE THEN
INSERT INTO DEPT VALUES(A,B,C);
ELSE
RAISE exc;
END IF;
EXCEPTION 
WHEN exc THEN
dbms_output.put_line('Duplicate Record Error');
END ADD_DEPT;
/**/
PROCEDURE UPDATE_DEPT(DEPTNO NUMBER,DNAME VARCHAR2,LOC VARCHAR2) IS
A NUMBER:=DEPTNO;
B VARCHAR2(14):=DNAME;
L VARCHAR2(13):=LOC;
N NUMBER;
BEGIN
IF  CAL_CNT(A)=TRUE THEN
SELECT DEPTNO INTO N FROM DEPT WHERE DEPTNO=A;
UPDATE DEPT SET DNAME=B,LOC=L WHERE DEPTNO=A;
ELSE
dbms_output.put_line('Department No.does not exist');
END IF;
EXCEPTION 
WHEN NO_DATA_FOUND THEN
dbms_output.put_line('Department No.does not exist');
END UPDATE_DEPT;
/**/
PROCEDURE DELETE_DEPT(DEPTNO NUMBER) IS
A NUMBER:=DEPTNO;
BEGIN
IF  CAL_CNT(A)=TRUE THEN
DELETE FROM DEPT WHERE DEPTNO=A;
IF SQL%NOTFOUND THEN
RAISE no_data_found;
END IF;
ELSE
dbms_output.put_line('Department No.does not exist');
END IF;
EXCEPTION 
WHEN no_data_found THEN
dbms_output.put_line('Department No.does not exist');
END DELETE_DEPT;

END PK1;

/*** Calling the package procedures***/

DECLARE
dno number:=&dno;
dname VARCHAR2(20):=&dname;
loc VARCHAR2(20):=&loc;
n dept%rowtype;
ro number:=0;
BEGIN
pk1.add_dept(dno,dname,loc);
pk1.update_dept(dno,dname,loc);
pk1.delete_dept(dno);
for c in (SELECT* FROM DEPT)
LOOP
n.deptno:=c.deptno;
n.dname:=c.dname;
n.loc:=c.loc;
dbms_output.put_line(n.deptno||' '||n.dname||' '||n.loc);
ro:=ro+1;
END LOOP;
ro:=ro-1;
dbms_output.put_line('Total number of rows are '||ro); 
END;


