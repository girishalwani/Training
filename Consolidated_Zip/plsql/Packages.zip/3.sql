CREATE SEQUENCE s2
    INCREMENT BY 1
    START WITH 1
    NOMINVALUE
    NOMAXVALUE
    NOCYCLE;
    
    
CREATE OR REPLACE PACKAGE pk3 IS
    PROCEDURE add_emp(v_empno emp.empno%TYPE ,v_ename emp.ename%TYPE DEFAULT 'UNK',v_sal emp.sal%TYPE DEFAULT 1000);
    PROCEDURE add_emp(v_ename emp.ename%TYPE DEFAULT 'UNK',v_sal emp.sal%TYPE DEFAULT 1000);
    
END pk3;

CREATE OR REPLACE FUNCTION cal_emp(v_empno emp.empno%TYPE) RETURN BOOLEAN IS
        CURSOR cur IS SELECT * FROM emp WHERE empno=v_empno;
        var_cur emp%rowtype;
        BEGIN
            OPEN cur;
            FETCH cur INTO var_cur;
            
            IF cur%notfound THEN
                RETURN TRUE;
            ELSE
                RETURN FALSE;
            END IF;
            CLOSE cur;
END ;






CREATE OR REPLACE PACKAGE BODY pk3 IS
    PROCEDURE add_emp(v_empno emp.empno%TYPE ,v_ename emp.ename%TYPE DEFAULT 'UNK',v_sal emp.sal%TYPE DEFAULT 1000) IS
    excp EXCEPTION;
    eno emp.empno%TYPE;
    exc EXCEPTION;
    BEGIN
        IF cal_emp(v_empno) THEN
            INSERT INTO emp(empno,ename,sal) VALUES(v_empno,v_ename,v_sal);
        ELSE
            RAISE excp;
        END IF;    
        
        EXCEPTION
            WHEN excp THEN
                dbms_output.put_line('values already present');
            WHEN OTHERS THEN
                dbms_output.put_line('addedd to dept');
    END add_emp;
    
    
    PROCEDURE add_emp(v_ename emp.ename%TYPE DEFAULT 'UNK',v_sal emp.sal%TYPE DEFAULT 1000) IS
    excp EXCEPTION;
    eno emp.empno%TYPE;
    exc EXCEPTION;
    BEGIN
        eno:=s2.NEXTVAL;
        IF cal_emp(eno) THEN
            INSERT INTO emp(empno,ename,sal) VALUES(eno,v_ename,v_sal);
        ELSE
            RAISE excp;
        END IF;    
        
        EXCEPTION
            WHEN excp THEN
                dbms_output.put_line('values already present');
            WHEN OTHERS THEN
                dbms_output.put_line('addedd to dept');
    END add_emp;
END pk3;

BEGIN
    pk3.add_emp();
END;

SELECT * FROM emp;
