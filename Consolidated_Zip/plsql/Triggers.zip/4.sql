SELECT USER FROM dual;
CREATE OR REPLACE TRIGGER not_table
BEFORE DDL ON SCHEMA
DECLARE
excp EXCEPTION;
v_user VARCHAR2(20);
BEGIN
    SELECT USER INTO v_user FROM dual;
    IF(ora_dict_obj_type='TABLE' AND v_user='SCOTT') THEN
        RAISE excp;
    END IF;
    
    EXCEPTION 
     WHEN excp THEN
        dbms_output.put_line('you are not allowed to create table');
END;

