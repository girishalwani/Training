SET SERVEROUTPUT ON;
SELECT to_number(to_char(sysdate,'HH24'), '99') FROM dual;

CREATE OR REPLACE TRIGGER restr
BEFORE INSERT OR UPDATE OR DELETE ON emp
ENABLE
DECLARE
    hr NUMBER;
    exc EXCEPTION;
BEGIN
    SELECT to_number(to_char(sysdate,'HH24'), '99') INTO hr FROM dual;
    IF(hr>=9 OR hr<=7) THEN
        RAISE exc;
    END IF;
    
    EXCEPTION
        WHEN exc THEN
            dbms_output.put_line('not allowed to perform any operatin b/w 9 to 17');
        WHEN OTHERS THEN
            dbms_output.put_line('other error occured');
END;
