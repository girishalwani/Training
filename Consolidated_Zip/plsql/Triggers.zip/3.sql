CREATE OR REPLACE VIEW v3 AS 
SELECT empno,ename, JOB,sal,emp.deptno,dname,loc FROM emp,dept;

CREATE OR REPLACE TRIGGER to_insert
INSTEAD OF INSERT OR UPDATE ON v3
FOR EACH ROW
DECLARE
    v_deptno emp.deptno%TYPE;
    v_empno emp.empno%TYPE;
BEGIN
    IF(:OLD.deptno=:NEW.deptno) THEN
        UPDATE dept SET dname=:NEW.dname,loc=:NEW.loc WHERE deptno=:NEW.deptno;
    ELSE
        INSERT INTO dept VALUES (:NEW.deptno,:NEW.dname,:NEW.loc);
    END IF;
    
    IF(:OLD.empno=:NEW.empno) THEN
        UPDATE emp SET ename=:NEW.ename,sal=:NEW.sal,deptno=:NEW.deptno WHERE empno=:NEW.empno;
    ELSE
        INSERT INTO emp(empno,ename,sal,JOB,deptno) VALUES (:NEW.empno,:NEW.ename,:NEW.sal,:NEW.JOB,:NEW.deptno);
    END IF;
END;

SELECT *FROM emp;
SELECT*FROM v3;
