SELECT sysdate FROM dual;

CREATE OR REPLACE TRIGGER date_format_change
AFTER LOGON ON SCHEMA
BEGIN
    EXECUTE IMMEDIATE 'alter session set nls_date_format = ''DD/MM/YYYY'' ';
END;
