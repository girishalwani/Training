DROP TABLE audit_emp;
CREATE TABLE audit_emp(
    empid NUMBER,
    username VARCHAR2(30),
    trdate VARCHAR2(30),
    trtype VARCHAR2(20)
);


CREATE OR REPLACE TRIGGER emp_audit
BEFORE INSERT OR DELETE OR UPDATE ON emp 
FOR EACH ROW
ENABLE
DECLARE
    v_date VARCHAR2(30);
    v_user VARCHAR2(30);
BEGIN
    SELECT USER,to_char(sysdate,'DD/MON/YYYY HH24:MI:SS') INTO v_user,v_date FROM dual;
    
    IF inserting THEN
        INSERT INTO audit_emp VALUES(:NEW.empno,v_user,v_date,'I');
    ELSIF deleting THEN
        INSERT INTO audit_emp VALUES(:OLD.empno,v_user,v_date,'D');
    ELSIF updating THEN
        INSERT INTO audit_emp VALUES(:OLD.empno,v_user,v_date,'U');
    END IF;
END;


SELECT * FROM audit_emp;
SELECT*FROM emp;
INSERT INTO emp(empno,ename) VALUES (103,'Jack');

