SET SERVEROUTPUT ON;
DECLARE 
    v_job emp.job%type;
    total number(4);
BEGIN
    v_job:=&job;
    DELETE from emp where job=v_job;
    IF sql%found then
       total:=sql%rowcount;
       dbms_output.put_line('Number of rows deleted are: '||total);
    ELSE
       dbms_output.put_line('No rows deleted');
    END IF;   
END;

