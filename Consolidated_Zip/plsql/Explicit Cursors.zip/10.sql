DECLARE
n emp%ROWTYPE;
CURSOR C(dept number) IS SELECT * FROM emp WHERE ( dept IS NOT NULL AND deptno=dept  OR dept IS NULL AND deptno NOT IN (10,20)) FOR UPDATE;
BEGIN
OPEN c(10);
LOOP
FETCH c INTO n;
EXIT WHEN c%NOTFOUND;
update emp set sal=sal+sal*0.15 where empno=n.empno;
DBMS_OUTPUT.PUT_LINE(n.ename||' '||n.deptno||' '||n.sal);
END LOOP;
CLOSE c;
OPEN c(20);
LOOP
FETCH c INTO n;
EXIT WHEN c%NOTFOUND;
update emp set sal=sal+sal*0.15 where empno=n.empno;
DBMS_OUTPUT.PUT_LINE(n.ename||' '||n.deptno||' '||n.sal);
END LOOP;
CLOSE c;
OPEN c(dept=>NULL);
LOOP
FETCH c INTO n;
EXIT WHEN c%NOTFOUND;
update emp set sal=sal+sal*0.05 where empno=n.empno;
DBMS_OUTPUT.PUT_LINE(n.ename||' '||n.deptno||' '||n.sal);
END LOOP;
CLOSE c;
FOR cursor1 IN (SELECT * FROM emp) 
          LOOP
            DBMS_OUTPUT.PUT_LINE('Employee name = ' || cursor1.ename||
                               ', Updated salary = ' || cursor1.sal);
          END LOOP;
END;


rollback
