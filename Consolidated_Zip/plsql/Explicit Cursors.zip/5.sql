SET SERVEROUTPUT ON;
DECLARE
n emp%ROWTYPE;
CURSOR c IS SELECT *  FROM (SELECT * FROM EMP WHERE SAL>2000 AND hiredate>('15-jun-1981'));
BEGIN
OPEN c;
LOOP
FETCH c INTO n;
EXIT WHEN c%NOTFOUND;
dbms_output.Put_line(n.ename|| ' earns '|| n.sal||' and joined the organization on '|| n.hiredate);
END LOOP;
CLOSE c;
END;
