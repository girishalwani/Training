DECLARE
v_asterisk emp.star%TYPE := NULL;
n emp%ROWTYPE;
CURSOR C(deptnumber number) IS SELECT NVL(ROUND(sal/1000), 0),ENAME FROM emp WHERE DEPTNO=deptnumber FOR UPDATE;
BEGIN
OPEN C(10);
LOOP
FETCH C INTO n.sal,n.ename;
EXIT WHEN c%NOTFOUND;
dbms_output.Put_line(n.ename||' '||n.sal);
FOR i IN 1..n.sal
LOOP
v_asterisk := v_asterisk ||'*';
END LOOP;
dbms_output.Put_line(v_asterisk);
UPDATE emp SET star = v_asterisk WHERE CURRENT OF C;
v_asterisk :=NULL;
END LOOP;
CLOSE C;
END;

