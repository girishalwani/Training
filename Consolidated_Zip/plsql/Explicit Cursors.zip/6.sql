SET SERVEROUTPUT ON;
DECLARE
n emp%ROWTYPE;
day VARCHAR2(20);
CURSOR c IS SELECT ENAME,TO_DATE(hiredate, 'DD-MM-RRRR')"Hire Date",TO_CHAR(hiredate, 'DAY')"DAY" FROM EMP ORDER BY TO_CHAR(hiredate+1,'d');
BEGIN
OPEN c;
LOOP
FETCH c INTO n.ename,n.hiredate,day;
EXIT WHEN c%NOTFOUND;
dbms_output.Put_line(n.ename|| ' '|| n.hiredate||' '|| day);
END LOOP;
CLOSE c;
END;
/




