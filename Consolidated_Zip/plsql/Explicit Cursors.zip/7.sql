SET SERVEROUTPUT ON;
DECLARE
n emp%ROWTYPE;
day VARCHAR2(20);
CURSOR c IS SELECT ENAME,NVL(COMM,0)"COMM"FROM EMP;
BEGIN
OPEN c;
dbms_output.Put_line('NAME'|| '         '||'COMM');
LOOP
FETCH c INTO n.ename,n.comm;
EXIT WHEN c%NOTFOUND;
IF n.comm!=0 then
dbms_output.Put_line(n.ename||'         '||n.comm );
ELSE
dbms_output.Put_line(n.ename||'         '||'NO COMMISSION');
END IF;
END LOOP;
CLOSE c;
END;
/