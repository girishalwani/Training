set serveroutput on;
create or replace procedure get_emp(v_empno in emp.empno%type,v_ename out emp.ename%type,v_sal out emp.sal%type) is
excp exception;
e_name emp.ename%type;
e_sal emp.sal%type;
begin
    select ename,sal into e_name,e_sal from emp where empno=v_empno;
    v_ename:=e_name;
    v_sal:=e_sal;
    
    exception
        when no_data_found then
            dbms_output.put_line('There is no such employee');
        when others then
            dbms_output.put_line(sqlerrm);
end;

declare
    eno emp.empno%type;
    enm emp.ename%type;
    esl emp.sal%type;
begin
    eno:=&eno;
    get_emp(eno,enm,esl);
    dbms_output.put_line(enm||' '||esl);
end;

