
create or replace procedure mobile(A IN VARCHAR2,B OUT VARCHAR2) is
BEGIN
SELECT REGEXP_REPLACE(A,'(...)(...)(....)','(\1)\2-\3')"REGEXP_REPLACE" INTO B FROM DUAL;
DBMS_OUTPUT.put_line(B);
END;

DECLARE
A VARCHAR2(23);
B VARCHAR2(23);
BEGIN
A:=9999999999;
mobile(A,B);
END;


