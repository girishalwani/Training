/*Procedure*/
set serveroutput on
create or replace procedure add_emp(v_deptno emp.deptno%type) is
excp exception;
A NUMBER;
cursor cur(dno emp.deptno%type) is select * from emp where deptno=dno;
begin
    SELECT deptno INTO A FROM DEPT WHERE DEPTNO=v_deptno;
    for val in cur(v_deptno) loop
        insert into emp_test(empno,ename,sal,deptno) values (val.empno,val.ename,val.sal,val.deptno);
        update emp set sal=val.sal*1.20 where empno=val.empno and deptno=val.deptno;
    end loop;
    exception
        when no_data_found then
            dbms_output.put_line('There is no such department');
end;

/*Calling Procedure*/
Begin
    add_emp(10);
end;



