/*Procedure*/
set serveroutput on
create or replace procedure del_emp(v_deptno emp.deptno%type) is
excp exception;
A NUMBER;
cursor cur(dno emp.deptno%type) is select * from emp where deptno=dno;
begin
    SELECT deptno INTO A FROM DEPT WHERE DEPTNO=v_deptno;
    for val in cur(v_deptno) loop
        insert into test1 select * from emp where empno=val.empno and deptno=val.deptno;
        delete from emp where empno=val.empno and deptno=val.deptno;
    end loop;
    exception
        when no_data_found then
            dbms_output.put_line('There is no such department');
end;

/*Calling Procedure*/
BEGIN
del_emp(10);
END;

