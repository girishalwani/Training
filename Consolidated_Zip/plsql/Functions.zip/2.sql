
CREATE OR REPLACE FUNCTION GET_ANNUAL_SAL(p_sal IN emp.sal%TYPE)
RETURN NUMBER IS
BEGIN
RETURN (NVL(p_sal,0) * 12);
END get_annual_sal;
/

/*Calling function result in select statement*/
DECLARE
A NUMBER;
b emp%rowtype;
eno NUMBER;
z NUMBER;
BEGIN
FOR C IN (SELECT * INTO b FROM emp WHERE deptno=30)
 LOOP
 A:=C.sal;
 eno:=C.empno;
 SELECT get_annual_sal(A) AS sal INTO z FROM emp WHERE empno=eno;
 dbms_output.put_line(C.ename||' '||z);
 END LOOP;
END;
