CREATE OR REPLACE FUNCTION numbertoword(n NUMBER) RETURN VARCHAR2 IS
  res VARCHAR2(34);
BEGIN
res := REPLACE(
  REPLACE(
    REPLACE(
      REPLACE(
        REPLACE(
          REPLACE(
            REPLACE(
              REPLACE(
                REPLACE(
                  REPLACE(n,
                    '0','zero '),
                  '1','one '),
                '2','two '),
              '3','three '),
            '4','four '),
          '5','five '),
        '6','six '),
      '7','seven '),
    '8','eight '),
  '9','nine ');
RETURN res;
END;

BEGIN
dbms_output.put_line(numbertoword(1234));
END;