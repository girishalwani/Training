CREATE OR REPLACE FUNCTION GET_JOB( eno IN emp.empno%TYPE)
RETURN VARCHAR2
AS
v_jobtitle emp.job%TYPE;
BEGIN
SELECT job INTO v_jobtitle FROM emp WHERE empno=eno;
RETURN v_jobtitle;
END GET_JOB;


/*Calling function result in session variable*/
DECLARE
v_jobtitle VARCHAR2(200);
b VARCHAR2(200);
BEGIN
v_jobtitle := GET_JOB(7788);
:b:= v_jobtitle;
DBMS_OUTPUT.PUT_LINE(:b);
END;
/



