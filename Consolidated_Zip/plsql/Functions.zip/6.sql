/*FUNCTION*/
CREATE OR REPLACE FUNCTION salstatus(v_sal IN emp.sal%TYPE)
RETURN BOOLEAN IS
v_dummy NUMBER;
BEGIN
SELECT AVG(sal) INTO v_dummy FROM emp;
IF v_sal<v_dummy THEN
RETURN TRUE;
END IF;
RETURN FALSE;
END salstatus;

/*PROCEDURE*/
CREATE OR REPLACE PROCEDURE REC_INSUPD(a emp.ename%TYPE,b emp.empno%TYPE,
c emp.sal%TYPE) IS
N number;
BEGIN
IF salstatus(c) THEN
SELECT sal INTO N FROM EMP WHERE empno=b;
UPDATE EMP SET SAL=c WHERE empno=b;
ELSE
RAISE_APPLICATION_ERROR (-20204, 'Invalid Salary.Try again.');
END IF;
EXCEPTION
when no_data_found then
INSERT INTO emp(ename,empno,sal)values(a,b,c);
END REC_INSUPD;

/*CALL*/
BEGIN
REC_INSUPD('Jack',1234,7000);
END;


