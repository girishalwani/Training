CREATE OR REPLACE FUNCTION hiredon(eno number)RETURN VARCHAR2 IS
n emp.hiredate%type;
op varchar2(243);
BEGIN
SELECT hiredate into n from emp where empno=eno;
SELECT TO_CHAR(n,'Day,MonthDD,YYYY', 'NLS_DATE_LANGUAGE = '''||'GERMAN'||'''') INTO OP FROM DUAL;
return op;
end;

BEGIN 
DBMS_OUTPUT.PUT_LINE(hiredon(&eno));
END;
