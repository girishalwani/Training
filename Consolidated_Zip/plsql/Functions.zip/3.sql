CREATE OR REPLACE FUNCTION valid_deptid(dno IN dept.deptno%TYPE)
RETURN BOOLEAN IS
v_dummy PLS_INTEGER;
BEGIN
SELECT 1 INTO v_dummy FROM dept WHERE deptno=dno;
RETURN TRUE;
EXCEPTION
WHEN NO_DATA_FOUND THEN
RETURN FALSE;
END valid_deptid;

CREATE OR REPLACE PROCEDURE add_employee(a emp.ename%TYPE,b emp.empno%TYPE,
c emp.sal%TYPE,dno dept.deptno%TYPE) IS
BEGIN
IF valid_deptid(dno) THEN
INSERT INTO emp(ename,empno,sal,deptno)values(a,b,c,dno);
ELSE
RAISE_APPLICATION_ERROR (-20204, 'Invalid department ID.Try again.');
END IF;
END add_employee;

BEGIN
add_employee('jac',1234,1234,30);
END;

