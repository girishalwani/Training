CREATE OR REPLACE FUNCTION CAL_REVERSE(str IN VARCHAR2) RETURN VARCHAR2 IS
len  NUMBER; 
str1 VARCHAR2(20):=' ';
BEGIN 
    len := Length(str); 
    FOR i IN REVERSE 1.. len LOOP                 
        str1 := str1 || Substr(str, i, 1); 
    END LOOP;  
    return str1;
END; 

/*Function Call*/
BEGIN
 dbms_output.Put_line(CAL_REVERSE('ABC'));
END;