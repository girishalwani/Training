CREATE OR REPLACE FUNCTION CAL_PCT(eno IN emp.empno%TYPE,p_sal IN emp.sal%TYPE,pr NUMBER DEFAULT 16)
RETURN NUMBER IS
BEGIN
RETURN (pr*NVL(p_sal,0)/100);
END CAL_PCT;
/


/*Calling function result in select statement*/
DECLARE
A NUMBER;
b emp%rowtype;
eno NUMBER;
z NUMBER;
pr NUMBER;
BEGIN
FOR C IN (SELECT * INTO b FROM emp)
 LOOP
 A:=C.sal;
 eno:=C.empno;
 z:=CAL_PCT(eno,A); 
 dbms_output.put_line(C.ename||' '||z);
 END LOOP;
END;