"""
Write a program to append a new item to the end of the list.
"""


list=[1,2,3,4]
print('old list - ',list)
list.append('new item')
list.insert(2,10)
print('new list - ',list)

