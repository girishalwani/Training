"""
Write a program to print the number of occurrences of a
specified element in a list.
"""


list=[1,1,1,1,1,1,2,3,2,2,4,5,6,4,3,2,2,2,1,1]
n=list.count(1)
print('no of 1 in list - ',n)
