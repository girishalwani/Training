"""
Write a program to reverse the order of the items in the list.
"""

list=[1,2,3,4,5,6,7,8,9,10]
print('normal - ',list)
list.reverse()
print('reverse - ',list)
