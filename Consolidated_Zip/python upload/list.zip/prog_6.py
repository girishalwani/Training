"""
Write a program to insert a new item before the second element
in an existing list.
"""


list=[1,2,3,4,5]
print('origianl - ',list)
list.insert(1,"one")
print('inserted at before second element - ',list)
