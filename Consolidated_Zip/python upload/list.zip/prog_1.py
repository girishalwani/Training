"""
Write a program to create a list of 5 integers and display the list items.
Access individual elements through index.
"""


list=[1,2,3,4,5]
print(list)
print('1st element - ',list[0])
print('2th element - ',list[1])
print('3th element - ',list[2])
print('4th element - ',list[3])
print('5th element - ',list[4])
