"""
Write a program to remove the item from a specified index in a list.
"""

list=[1,'one',2,'two',3,'three',4,'four',5,'five']
print('original list - ',list)
del list[2]
print('remove at index 2 - ',list)
del list[2]
print('remove at index 2 again - ',list)
