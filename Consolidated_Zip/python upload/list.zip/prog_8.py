"""
Write a program to remove the first occurrence of a
specified element from a list.
"""


list=[1,2,3,4,5,4,3,2,1]
print('origianl list - ',list)
list.remove(3)
print('remove first occurance of 3 - ',list)
