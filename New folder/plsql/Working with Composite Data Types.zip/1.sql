SET SERVEROUTPUT ON

DECLARE 
i emp%ROWTYPE;
BEGIN
SELECT* INTO i FROM EMP WHERE EMPNO=&EMPNO;
DBMS_OUTPUT.PUT_LINE(i.empno||' '||i.ename||' '||i.job||' '||i.mgr||' '||i.hiredate||' '||i.sal||' '||i.comm||' '||i.deptno);
END;
/
