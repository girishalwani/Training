SET SERVEROUTPUT ON
DECLARE 
 A NUMBER;
 B NUMBER;
BEGIN
 A:=&EMPNO;
 SELECT DEPTNO INTO  B FROM EMP WHERE empno=A;
 IF B = 10 then 
 UPDATE emp SET sal=sal* 1.10 WHERE empno=A;
 ELSIF B = 20 then 
 UPDATE emp SET sal=sal* 1.15 WHERE empno=A;
 ELSE 
 UPDATE emp SET sal=sal+NVL(comm,0)WHERE empno=A;
 END IF;
 END;
 /
 