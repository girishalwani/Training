CREATE TABLE MYTABLE1 (RESULT NUMBER(10));
DECLARE 
   a number(2); 
BEGIN 
   FOR a in 1 .. 10  LOOP
      IF a!=6 and a!=8 then
      INSERT INTO MYTABLE1(RESULT) VALUES (a) ;
      END IF;
  END LOOP; 
END; 
/
