execute deptree_fill('table', 'myc', 'emp');
SELECT NESTED_LEVEL,TYPE,SCHEMA,SEQ#  FROM DEPTREE;
