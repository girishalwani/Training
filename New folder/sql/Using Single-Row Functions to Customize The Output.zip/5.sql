SELECT INITCAP(ename),LENGTH(ename)FROM emp
WHERE ename LIKE '&start_letter%'
ORDER BY ename;
