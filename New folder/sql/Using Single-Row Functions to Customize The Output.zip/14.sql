SELECT job, CASE job
       WHEN 'CLERK' THEN 'D'
       WHEN 'SALESMAN' THEN 'C'
       WHEN 'MANAGER' THEN 'B'
       WHEN 'PRESIDENT' THEN 'A'
       ELSE 'other' END GRADE
FROM   emp