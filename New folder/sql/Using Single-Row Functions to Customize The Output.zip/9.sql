select ename, hiredate, to_char(NEXT_DAY(ADD_MONTHS(hiredate, 6),'Monday'),'Fmday," the "Ddspth "of" Month,yyyy') REVIEW
     from emp;