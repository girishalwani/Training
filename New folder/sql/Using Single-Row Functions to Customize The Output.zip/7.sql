SELECT ename ||' earns '|| TO_CHAR(sal,'fm$99,999.00') 
       || ' monthly but wants '|| TO_CHAR(sal * 3, 'fm$99,999.00') "Dream Salaries"
FROM   emp; 