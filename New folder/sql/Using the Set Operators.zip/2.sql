select to_char(deptno),sum(sal) as total_salary from emp group by deptno
union
select job, sum(sal) as total_salary from emp group by job

