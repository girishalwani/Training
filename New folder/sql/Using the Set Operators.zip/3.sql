select job, deptno
from (
  select job, deptno  from emp where deptno = 10
  union
  select job, deptno  from emp where deptno = 20
  union 
  select job, deptno from emp where deptno = 30
) 
ORDER BY (
    CASE deptno
    when 20
    then 1
    when 10
    then 2
    when 30
    then 3
    END
)
    