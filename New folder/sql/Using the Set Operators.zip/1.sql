SELECT   job "Job",
         SUM(DECODE(deptno,10,sal)) "Dept 10",
         SUM(DECODE(deptno,20,sal)) "Dept 20",
         SUM(DECODE(deptno,30,sal)) "Dept 30",
         SUM(sal) "Total"
FROM     emp
GROUP BY job;