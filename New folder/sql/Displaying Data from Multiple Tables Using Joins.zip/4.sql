SELECT w.ename "Employee", w.empno "EMP#",
m.ename"Manager", m.empno "Mgr#"
FROM emp w join emp m
ON (w.mgr = m.empno);