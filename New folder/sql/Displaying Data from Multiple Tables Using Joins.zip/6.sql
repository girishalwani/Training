DESC salgrade
SELECT e.ename, e.job, d.dname,
e.sal, s.grade
FROM emp e JOIN dept d
ON (e.deptno = d.deptno)
JOIN salgrade s
ON (e.sal BETWEEN s.losal AND s.hisal);