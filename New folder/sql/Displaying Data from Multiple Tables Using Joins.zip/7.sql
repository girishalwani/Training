SELECT e.ename,d.dname 
from emp e RIGHT OUTER JOIN dept d
ON e.deptno=d.deptno;
