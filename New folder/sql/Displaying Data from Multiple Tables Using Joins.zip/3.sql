SELECT JOB,ENAME,DEPTNO,DNAME from emp 
NATURAL JOIN dept
where loc='DALLAS'


