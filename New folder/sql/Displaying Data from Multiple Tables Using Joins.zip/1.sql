SELECT empno,ename,sal,dname,loc
FROM emp
NATURAL JOIN dept