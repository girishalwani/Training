SELECT w.ename "Employee", w.empno "EMP#",
m.ename"Manager", m.empno "Mgr#"
FROM emp w 
LEFT OUTER JOIN emp m
ON (w.mgr = m.empno)
ORDER BY w.empno;