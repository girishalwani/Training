SELECT e.ename"Employee",e.hiredate "Hiredate",m.ename"MANAGER",m.hiredate"Hiredate" from emp e JOIN emp m ON(e.mgr=m.empno)
WHERE e.hiredate<m.hiredate;