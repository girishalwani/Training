SELECT ROUND(MAX(sal), 0) "Maximum",
       ROUND(MIN(sal), 0) "Minimum",
       ROUND(SUM(sal), 0) "Sum",
       ROUND(AVG(sal), 0) "Average"
FROM   emp;