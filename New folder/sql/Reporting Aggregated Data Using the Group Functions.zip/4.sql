SELECT   job,COUNT(*)
FROM     emp
GROUP BY job;