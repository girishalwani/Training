SELECT COUNT(*) total,
       SUM(DECODE(TO_CHAR(hiredate, 'YYYY'), 1980,1,0)) "Employees hired in 1980",
       SUM(DECODE(TO_CHAR(hiredate, 'YYYY'), 1981,1,0)) "Employees hired in 1981",
       SUM(DECODE(TO_CHAR(hiredate, 'YYYY'), 1982,1,0)) "Employees hired in 1982"
FROM   emp;