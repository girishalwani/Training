SELECT COUNT(DISTINCT mgr) "Number Of Managers"
FROM   emp;