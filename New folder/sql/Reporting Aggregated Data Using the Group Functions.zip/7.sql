SELECT   mgr, MIN(sal)
FROM     emp
WHERE    mgr IS NOT NULL
GROUP BY mgr
HAVING   MIN(sal) > 2000
ORDER BY MIN(sal) DESC;