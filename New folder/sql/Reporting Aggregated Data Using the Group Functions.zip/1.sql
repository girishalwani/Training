SELECT MAX(sal) "Maximum",
       MIN(sal) "Minimum",
       SUM(sal)  "Sum",
       AVG(sal) Average
FROM   emp;