"""
 Write a program to remove a given item from the set.
"""

set={1,2,3,4,5,6,7,8,9,0}
print(set)
print('remove 5 from set',set.remove(5))
print('remove 9 from set',set.remove(9))
print(set)
