"""
Write a program to find the maximum and minimum value in a set.
"""

set={1,2,3,4,5,6,7,8,9}

print('max = ',max(set))
print('min = ',min(set))
