"""
Write a program to create an intersection of sets.
"""

set1={1,2,3,4}
set2={3,4,5,6}
set3={1,3,5,7}


print('set1 intersection set2 =',set1.intersection(set2))
print('set1 intersection set2 intersection set3 =',set1.intersection(set2,set3))
