"""
Write a program to check if a given number is Positive, Negative, or Zero.
"""


num = int(input())

if(num==0):
    print('zero')
else:
    if(num>0):
        print('positive')
    else:
        print('negative')
