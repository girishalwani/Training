"""
Write a program to check if a given number is odd or even.
"""

num =int(input())

if(num%2==0):
    print('even')
else:
    print('odd')
    
