"""
Write a program to print even numbers between 23 and 57.
Each number should be printed in a separate row.
"""

for i in range(23,57,1):
    if(i%2==0):
        print(i)
    else:
        continue
