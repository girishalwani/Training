"""
Write a program to print numbers from 1 to 10
in a single row with one tab space.
"""

for i in range(0,10,1):
    print(i+1,end=' ')
