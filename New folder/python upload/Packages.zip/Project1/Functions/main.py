import Functions as f
f.math_module.add(10,5)
f.math_module.sub(10,5)
f.math_module.mul(10,5)
f.math_module.div(10,5)

